# IMX462 Jetson Orin Nano — User Manual

Sony IMX462 (Starvis gen1) dual-camera tegracam driver for the NVIDIA Jetson
Orin Nano (L4T r36.4.x / JetPack 6, kernel 5.15-tegra, T234; p3768 carrier +
p3767 module). Supports CAM0 + CAM1, 1920×1080 RAW10.

**Supported board crystal: 74.25 MHz → 1080p60 (891 Mbit/s/lane).**

---

## 1. What you get

- One driver module `imx462.ko` that drives CAM0 and CAM1.
- Device-tree overlays for single (`cam0`, `cam1`) and dual (`cam0+cam1`) operation:
  - `tegra234-imx462-cam0.dtbo` — single camera on CAM0, 1080p60
  - `tegra234-imx462-cam1.dtbo` — single camera on CAM1, 1080p60
  - `tegra234-imx462-dual.dtbo` — dual CAM0+CAM1, 1080p60
- A calibrated ISP override (`camera_overrides.imx462_tuned.isp`) that applies the
  IMX462 color correction for the Argus pipeline.

---

## 2. Install

Run the installer with `sudo`, then activate ONE overlay with jetson-io and reboot.

```bash
sudo bash scripts/install_binary.sh
```

> The installer never edits `/boot/extlinux/extlinux.conf` and never reboots.
> Overlays are activated only through jetson-io.

---

## 3. Overlay activation

Activate the overlay matching your use case (CSI connector is header **2** on the Orin Nano):

```bash
# List header number + exact overlay names available on your board:
sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -l

# Single camera on CAM0 (1080p60):
sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -n '2=Camera IMX462 CAM0'

# Single camera on CAM1 (1080p60):
sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -n '2=Camera IMX462 CAM1'

# Dual CAM0+CAM1 (1080p60):
sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -n '2=Camera IMX462 Dual (CAM0+CAM1)'

sudo reboot
```

---

## 4. HCG / LCG conversion-gain switching (sysfs)

The IMX462 has two analog conversion-gain modes: **LCG** (low conversion gain,
default — higher full-well / dynamic range) and **HCG** (high conversion gain —
lower read noise in low light). This is exposed as a runtime sysfs parameter:

```bash
# Read current mode (0 = LCG, 1 = HCG):
cat /sys/module/imx462/parameters/hcg_mode

# Switch to HCG:
echo 1 | sudo tee /sys/module/imx462/parameters/hcg_mode

# Switch back to LCG:
echo 0 | sudo tee /sys/module/imx462/parameters/hcg_mode
```

The new mode takes effect on the **next stream start**. If a camera is already
streaming, stop and restart the stream (or restart `nvargus-daemon` for Argus):

```bash
sudo systemctl restart nvargus-daemon
```

You can also set it at load time: `modprobe imx462 hcg_mode=1`.

---

## 5. Camera ↔ device-node mapping

| Connector | I²C       | V4L2 node    | Argus `sensor-id` |
|-----------|-----------|--------------|-------------------|
| CAM0      | `9-001a`  | `/dev/video0`| **1**             |
| CAM1      | `10-001a` | `/dev/video1`| **0**             |

> Note: the Argus `sensor-id` order is **reversed** versus `/dev/videoN`. The
> V4L2-node ↔ I²C-bus mapping is the ground truth.

---

## 6. Capturing

**Raw V4L2** (direct sensor data, Bayer RG10):

```bash
v4l2-ctl -d /dev/video0 \
  --set-fmt-video=width=1920,height=1080,pixelformat=RG10 \
  --stream-mmap --stream-count=120
# prints the measured fps; ~60 on a 74.25 MHz board
```

**Argus** (full ISP pipeline, color-corrected) — capture a still:

```bash
# CAM0 is Argus sensor-id 1; CAM1 is sensor-id 0
bash scripts/capture_argus_image.sh /tmp/cam.jpg     # see the script for sensor-id
```

Or a live preview / GStreamer pipeline:

```bash
gst-launch-1.0 nvarguscamerasrc sensor-id=1 \
  ! 'video/x-raw(memory:NVMM),width=1920,height=1080,framerate=60/1' \
  ! nvvidconv ! autovideosink
```

> Tip: let a `v4l2-ctl --stream-mmap` capture finish (use a small
> `--stream-count`) rather than interrupting it (Ctrl-C / kill). If raw captures
> stop returning frames after an interrupted run, reload the driver:
> `sudo rmmod imx462 && sudo modprobe imx462`.

---

## 7. Color / ISP

The Argus color path uses `/var/nvidia/nvcam/settings/camera_overrides.isp`,
installed from `camera_overrides.imx462_tuned.isp`. It applies the calibrated
color correction for the IMX462.

- Edits to the override require `sudo systemctl restart nvargus-daemon` to take
  effect (Argus caches it at startup).
- The installer backs up any pre-existing override to
  `/var/nvidia/nvcam/settings/backup_imx462_isp/` before overwriting.
- One override file is global to all Argus cameras, so CAM0 and CAM1 share it.

---

## 8. Troubleshooting

| Symptom | Likely cause / fix |
|---|---|
| `modprobe imx462` → `invalid module format` | The prebuilt `.ko` was built for a different kernel. Check `uname -r` matches `5.15.148-tegra`. |
| `/dev/video0` exists but capture times out, zero frames | CAM0 CSI not locking — confirm you activated an IMX462 overlay and rebooted. If it started after killing a capture, reload the module (see §6 tip). |
| CAM0 probe fails with `-121` (EREMOTEIO) | Use the provided overlays unchanged (do not modify the CAM0 overlay). |
| Argus image colors look off | Confirm the tuned ISP is installed and `nvargus-daemon` was restarted. |
| jetson-io does not list the overlays | The installer stamps your CSI header name into each dtbo; ensure `device-tree-compiler` (provides `fdtput`) is installed and re-run the installer. |

---

## 9. Specifications (verified)

- Sensor: Sony IMX462 (Starvis gen1), 1/2.8", rolling shutter, color.
- Resolution / format: 1920×1080, RAW10 (Bayer RGGB), 2-lane MIPI CSI-2 D-PHY.
- Frame rate: **1080p60** (74.25 MHz crystal), down to 2 fps via the frame-rate control.
  Both cams verified streaming simultaneously, 0 dropped.
- Conversion gain: LCG / HCG runtime-switchable (sysfs).
