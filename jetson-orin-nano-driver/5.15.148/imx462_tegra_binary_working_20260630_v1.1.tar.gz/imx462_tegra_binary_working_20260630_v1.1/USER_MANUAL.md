# IMX462 Jetson Orin Nano — User Manual

Sony IMX462 (Starvis gen1) dual-camera tegracam driver for the NVIDIA Jetson
Orin Nano (L4T r36.4.x / JetPack 6, kernel 5.15-tegra, T234; p3768 carrier +
p3767 module). Supports CAM0 + CAM1, 1920×1080 RAW10, and **both INCK crystals**
(37.125 MHz → 1080p30, 74.25 MHz → 1080p60) from one driver binary.

---

## 1. What you get

- One driver module `imx462.ko` that drives CAM0 and CAM1.
- Device-tree overlays for single (`cam0`, `cam1`) and dual (`cam0+cam1`)
  operation, in **two crystal variants**:
  - **74.25 MHz** board → `…cam0/cam1/dual.dtbo` → **1080p60** (891 Mbit/s/lane).
  - **37.125 MHz** board → `…cam0/cam1/dual-37m.dtbo` → **1080p30** (445.5 Mbit/s/lane).
- A calibrated ISP override (`camera_overrides.imx462_tuned.isp`) that applies the
  IMX462 color correction for the Argus pipeline.

The driver **auto-detects the crystal from the activated overlay** — you do not
set any module parameter. Just activate the overlay that matches your board.

---

## 2. Install

See `README.md` for your package (binary or source). In short: run the installer
with `sudo`, then activate ONE overlay with jetson-io and reboot.

> The installer never edits `/boot/extlinux/extlinux.conf` and never reboots.
> Overlays are activated only through jetson-io.

---

## 3. Crystal (INCK) switching — choose the matching overlay

The board crystal determines the maximum frame rate, and the driver configures
itself from whichever overlay you boot. **You do not rebuild or set a parameter —
you pick the overlay.**

| Your board crystal | Activate this dual overlay (jetson-io menu name)   | Result   |
|--------------------|----------------------------------------------------|----------|
| **74.25 MHz**      | `Camera IMX462 Dual (CAM0+CAM1)`                   | 1080p60  |
| **37.125 MHz**     | `Camera IMX462 Dual 30fps (37.125MHz)`            | 1080p30  |

Activate (CSI connector is header **2** on the Orin Nano):

```bash
# List header number + exact overlay names available on your board:
sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -l

# 74.25 MHz board, dual 1080p60:
sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -n '2=Camera IMX462 Dual (CAM0+CAM1)'

# 37.125 MHz board, dual 1080p30:
sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -n '2=Camera IMX462 Dual 30fps (37.125MHz)'

sudo reboot
```

For a single camera, use `Camera IMX462 CAM0` / `CAM1` (or the `… 30fps
(37.125MHz)` variants). After reboot, confirm which crystal the driver locked
onto:

```bash
sudo dmesg | grep -iE 'imx462 .*: inck'
#   74.25 MHz board reports:  inck 74250 ...   (1080p60)
#   37.125 MHz board reports: inck 37125 ...   (1080p30)
```

> Advanced override: the driver reads the crystal from the DT automatically. If
> you ever need to force it, load with `modprobe imx462 inck_khz=74250` (or
> `37125`). The default `inck_khz=0` means "auto from DT" — leave it at 0 for
> normal use.

---

## 4. HCG / LCG conversion-gain switching (sysfs)

The IMX462 has two analog conversion-gain modes: **LCG** (low conversion gain,
default — higher full-well / dynamic range) and **HCG** (high conversion gain —
lower read noise in low light). This is exposed as a runtime sysfs parameter:

```bash
# Read current mode (0 = LCG, 1 = HCG):
cat /sys/module/imx462/parameters/hcg_mode

# Switch to HCG:
echo 1 | sudo tee /sys/module/imx462/parameters/hcg_mode

# Switch back to LCG:
echo 0 | sudo tee /sys/module/imx462/parameters/hcg_mode
```

The new mode takes effect on the **next stream start**. If a camera is already
streaming, stop and restart the stream (or restart `nvargus-daemon` for Argus):

```bash
sudo systemctl restart nvargus-daemon
```

You can also set it at load time: `modprobe imx462 hcg_mode=1`.

---

## 5. Camera ↔ device-node mapping

| Connector | I²C       | V4L2 node    | Argus `sensor-id` |
|-----------|-----------|--------------|-------------------|
| CAM0      | `9-001a`  | `/dev/video0`| **1**             |
| CAM1      | `10-001a` | `/dev/video1`| **0**             |

> Note: the Argus `sensor-id` order is **reversed** versus `/dev/videoN`. The
> V4L2-node ↔ I²C-bus mapping is the ground truth.

---

## 6. Capturing

**Raw V4L2** (direct sensor data, Bayer RG10):

```bash
v4l2-ctl -d /dev/video0 \
  --set-fmt-video=width=1920,height=1080,pixelformat=RG10 \
  --stream-mmap --stream-count=120
# prints the measured fps; ~60 on a 74.25 board, ~30 on a 37.125 board
```

**Argus** (full ISP pipeline, color-corrected) — capture a still:

```bash
# CAM0 is Argus sensor-id 1; CAM1 is sensor-id 0
bash scripts/capture_argus_image.sh /tmp/cam.jpg     # see the script for sensor-id
```

Or a live preview / GStreamer pipeline:

```bash
gst-launch-1.0 nvarguscamerasrc sensor-id=1 \
  ! 'video/x-raw(memory:NVMM),width=1920,height=1080,framerate=60/1' \
  ! nvvidconv ! autovideosink
```

> Tip: let a `v4l2-ctl --stream-mmap` capture finish (use a small
> `--stream-count`) rather than interrupting it (Ctrl-C / kill). If raw captures
> stop returning frames after an interrupted run, reload the driver:
> `sudo rmmod imx462 && sudo modprobe imx462`.

---

## 7. Color / ISP

The Argus color path uses `/var/nvidia/nvcam/settings/camera_overrides.isp`,
installed from `camera_overrides.imx462_tuned.isp`. It applies the calibrated
color correction for the IMX462.

- Edits to the override require `sudo systemctl restart nvargus-daemon` to take
  effect (Argus caches it at startup).
- The installer backs up any pre-existing override to
  `/var/nvidia/nvcam/settings/backup_imx462_isp/` before overwriting.
- One override file is global to all Argus cameras, so CAM0 and CAM1 share it.

---

## 8. Troubleshooting

| Symptom | Likely cause / fix |
|---|---|
| `modprobe imx462` → `invalid module format` | The prebuilt `.ko` was built for a different kernel. Use the **source** package and build against your running kernel. |
| `/dev/video0` exists but capture times out, zero frames | CAM0 CSI not locking — confirm you activated an IMX462 overlay and rebooted. If it started after killing a capture, reload the module (see §6 tip). |
| CAM0 probe fails with `-121` (EREMOTEIO) | Use the provided overlays unchanged (do not modify the CAM0 overlay). |
| Wrong frame rate (30 vs 60) | You activated the overlay for the other crystal. Re-activate the matching one (see §3) and reboot. |
| Argus image colors look off | Confirm the tuned ISP is installed and `nvargus-daemon` was restarted. |
| jetson-io does not list the overlays | The installer stamps your CSI header name into each dtbo; ensure `device-tree-compiler` (provides `fdtput`) is installed and re-run the installer. |

---

## 9. Specifications (verified)

- Sensor: Sony IMX462 (Starvis gen1), 1/2.8", rolling shutter, color.
- Resolution / format: 1920×1080, RAW10 (Bayer RGGB), 2-lane MIPI CSI-2 D-PHY.
- Frame rate: 1080p60 (74.25 MHz crystal) or 1080p30 (37.125 MHz crystal),
  down to 2 fps via the frame-rate control. Both cams verified streaming
  simultaneously, 0 dropped.
- Conversion gain: LCG / HCG runtime-switchable (sysfs).
