# IMX462 Jetson Orin Nano — Binary Package

Precompiled Sony IMX462 dual-camera driver for the NVIDIA Jetson Orin Nano
(L4T r36.4.x / JetPack 6, kernel 5.15-tegra, T234). Install, activate an overlay,
reboot — no compiler needed.

## Contents

```
binary/imx462.ko                 prebuilt, stripped driver module
overlays/*.dtbo                  3 device-tree overlays (cam0/cam1/dual, 74.25 MHz)
isp/camera_overrides.imx462_tuned.isp   color-corrected Argus ISP override
scripts/install_binary.sh        installer (no build; never touches extlinux)
scripts/capture_*.sh, preview_*.sh, *.py   capture / preview helpers
USER_MANUAL.md                   full usage: HCG switching, capture, ISP
CHECKSUMS.sha256                 integrity manifest
```

## Requirements

- Jetson Orin Nano, **kernel `5.15.148-tegra`** (the kernel the `.ko` was built
  against — check with `uname -r`). A different kernel needs the **source**
  package. `device-tree-compiler` (for `fdtput`) recommended.
- **Board crystal: 74.25 MHz** (1080p60). This package supports 74.25 MHz boards only.

## Install

```bash
sudo bash scripts/install_binary.sh
```

This installs the module + overlays + the tuned ISP, and stamps
your board's CSI header name into each overlay. It does **not** reboot and does
**not** edit `extlinux.conf`.

Then activate the overlay and reboot:

```bash
# Single camera on CAM0:
sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -n '2=Camera IMX462 CAM0'

# Single camera on CAM1:
sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -n '2=Camera IMX462 CAM1'

# Dual CAM0+CAM1:
sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -n '2=Camera IMX462 Dual (CAM0+CAM1)'

sudo reboot
```

## After reboot — quick check

```bash
ls /dev/video0 /dev/video1
v4l2-ctl -d /dev/video0 --set-fmt-video=width=1920,height=1080,pixelformat=RG10 \
  --stream-mmap --stream-count=120              # measured fps (~60)
```

See **USER_MANUAL.md** for HCG/LCG switching, the CAM↔node↔Argus-id mapping,
capture commands, and troubleshooting.

## Verify integrity

```bash
sha256sum -c CHECKSUMS.sha256
```
