# IMX462 Jetson Orin Nano — Binary Package

Precompiled Sony IMX462 dual-camera driver for the NVIDIA Jetson Orin Nano
(L4T r36.4.x / JetPack 6, kernel 5.15-tegra, T234). Install, activate an overlay,
reboot — no compiler needed.

## Contents

```
binary/imx462.ko                 prebuilt, stripped driver module
overlays/*.dtbo                  6 device-tree overlays (cam0/cam1/dual ×2 crystals)
isp/camera_overrides.imx462_tuned.isp   color-corrected Argus ISP override
scripts/install_binary.sh        installer (no build; never touches extlinux)
scripts/capture_*.sh, preview_*.sh, *.py   capture / preview helpers
USER_MANUAL.md                   full usage: crystal & HCG switching, capture, ISP
CHECKSUMS.sha256                 integrity manifest
```

## Requirements

- Jetson Orin Nano, **kernel `5.15.148-tegra`** (the kernel the `.ko` was built
  against — check with `uname -r`). A different kernel needs the **source**
  package. `device-tree-compiler` (for `fdtput`) recommended.

## Install

```bash
sudo bash scripts/install_binary.sh
```

This installs the module + both crystal overlay sets + the tuned ISP, and stamps
your board's CSI header name into each overlay. It does **not** reboot and does
**not** edit `extlinux.conf`.

Then activate the overlay matching **your board crystal** and reboot:

```bash
# 74.25 MHz board → 1080p60:
sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -n '2=Camera IMX462 Dual (CAM0+CAM1)'
# 37.125 MHz board → 1080p30:
sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -n '2=Camera IMX462 Dual 30fps (37.125MHz)'
sudo reboot
```

## After reboot — quick check

```bash
ls /dev/video0 /dev/video1
sudo dmesg | grep -iE 'imx462 .*: inck'        # shows the auto-detected crystal
v4l2-ctl -d /dev/video0 --set-fmt-video=width=1920,height=1080,pixelformat=RG10 \
  --stream-mmap --stream-count=120              # measured fps
```

See **USER_MANUAL.md** for crystal switching, HCG/LCG sysfs switching, the
CAM↔node↔Argus-id mapping, capture commands, and troubleshooting.

## Verify integrity

```bash
sha256sum -c CHECKSUMS.sha256
```
