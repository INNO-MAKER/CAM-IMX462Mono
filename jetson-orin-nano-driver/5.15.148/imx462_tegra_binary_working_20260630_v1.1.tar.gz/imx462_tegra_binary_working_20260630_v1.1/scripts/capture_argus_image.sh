#!/bin/bash
# Capture a JPEG via Argus ISP (AWB/AE/demosaic in hardware).
# Usage: ./capture_argus_image.sh [output.jpg]
#   SENSOR_ID=1 ./capture_argus_image.sh out.jpg   -> CAM1 (default 0 = CAM0)
set -e
OUT="${1:-/tmp/imx462_argus.jpg}"
SENSOR_ID="${SENSOR_ID:-0}"
W="${W:-1920}"
H="${H:-1080}"
FRAMERATE="${FRAMERATE:-30/1}"
NUM_BUFFERS="${NUM_BUFFERS:-30}"
gst-launch-1.0 -e nvarguscamerasrc sensor-id="$SENSOR_ID" sensor-mode=0 num-buffers="$NUM_BUFFERS" \
  ! "video/x-raw(memory:NVMM),width=${W},height=${H},format=NV12,framerate=${FRAMERATE}" \
  ! nvjpegenc \
  ! multifilesink location="$OUT" max-files=1
echo "saved: $OUT (sensor-id=$SENSOR_ID)"
