#!/bin/bash
# Capture a MONO still via Argus. The pipeline forces GRAY8 (luma only) after
# Argus, giving a clean grayscale image. Use for a mono IMX462 / IMX290 module,
# or to get a grayscale still from a color sensor.
# Usage: [SENSOR_ID=0|1] ./capture_argus_mono_image.sh [output.jpg|output.png]
set -e
OUT="${1:-/tmp/imx462_argus_mono.jpg}"
SENSOR_ID="${SENSOR_ID:-0}"
W="${W:-1920}"
H="${H:-1080}"
FRAMERATE="${FRAMERATE:-30/1}"
NUM_BUFFERS="${NUM_BUFFERS:-30}"
EXT="${OUT##*.}"
case "$EXT" in
  jpg|jpeg) ENC="jpegenc" ;;
  png)      ENC="pngenc" ;;
  *) echo "Unsupported extension .$EXT (use .jpg or .png)" >&2; exit 2 ;;
esac

echo "MONO capture ${W}x${H} sensor-id=${SENSOR_ID} -> $OUT (GRAY8 luma only)"
gst-launch-1.0 -e \
  nvarguscamerasrc sensor-id="$SENSOR_ID" sensor-mode=0 num-buffers="$NUM_BUFFERS" \
  ! "video/x-raw(memory:NVMM),width=${W},height=${H},format=NV12,framerate=${FRAMERATE}" \
  ! nvvidconv \
  ! "video/x-raw,format=GRAY8,width=${W},height=${H}" \
  ! videoconvert \
  ! "$ENC" \
  ! multifilesink location="$OUT" max-files=1
echo "saved: $OUT"
