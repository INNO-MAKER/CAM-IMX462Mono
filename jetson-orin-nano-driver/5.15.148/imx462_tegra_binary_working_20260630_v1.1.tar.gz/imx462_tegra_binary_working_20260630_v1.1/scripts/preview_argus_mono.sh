#!/bin/bash
# Live MONO preview via Argus. The pipeline forces GRAY8 after Argus NV12, so
# what you see is luma only. Use for a mono IMX462 / IMX290 module, or to preview
# a color sensor as grayscale.
# Usage: DISPLAY=:0 [SENSOR_ID=0|1] ./preview_argus_mono.sh [duration_seconds]
set -e
SENSOR_ID="${SENSOR_ID:-0}"
W="${W:-1920}"
H="${H:-1080}"
FRAMERATE="${FRAMERATE:-30/1}"
DURATION="${1:-0}"
PREVIEW_SINK="${PREVIEW_SINK:-}"

if [ -z "$PREVIEW_SINK" ]; then
  if gst-inspect-1.0 nv3dsink >/dev/null 2>&1; then PREVIEW_SINK="nv3dsink"
  elif gst-inspect-1.0 nveglglessink >/dev/null 2>&1; then PREVIEW_SINK="nveglglessink"
  else PREVIEW_SINK="autovideosink"; fi
fi

NUM_BUFFERS_ARG=()
if [ "$DURATION" -gt 0 ] 2>/dev/null; then
  NUM_BUFFERS=$(( DURATION * 30 ))
  NUM_BUFFERS_ARG=(num-buffers="$NUM_BUFFERS")
fi

echo "MONO preview ${W}x${H} sensor-id=${SENSOR_ID} sink=${PREVIEW_SINK} (GRAY8 luma only)"
gst-launch-1.0 -e \
  nvarguscamerasrc sensor-id="$SENSOR_ID" sensor-mode=0 "${NUM_BUFFERS_ARG[@]}" \
  ! "video/x-raw(memory:NVMM),width=${W},height=${H},format=NV12,framerate=${FRAMERATE}" \
  ! nvvidconv \
  ! "video/x-raw,format=I420,width=${W},height=${H}" \
  ! videoconvert ! "video/x-raw,format=GRAY8" \
  ! videoconvert ! "video/x-raw,format=I420" \
  ! fpsdisplaysink video-sink="$PREVIEW_SINK" text-overlay=false sync=false
