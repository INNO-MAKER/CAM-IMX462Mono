# IMX462 Scripts Reference

Capture and preview helpers for the IMX462 on the Jetson Orin Nano. Run them
after the driver is installed, an overlay is active, and (for Argus paths)
`nvargus-daemon` is running.

## Camera ↔ device mapping (dual overlay)

| Camera | V4L2 node    | Argus `sensor-id` | I²C bus |
|--------|--------------|-------------------|---------|
| CAM0   | `/dev/video0`| `1`               | 9       |
| CAM1   | `/dev/video1`| `0`               | 10      |

> The Argus `sensor-id` order is reversed versus the `/dev/videoN` index. The
> V4L2-node ↔ I²C mapping is the stable ground truth.

## Scripts

| Script | Output | Notes |
|--------|--------|-------|
| `capture_v4l2_image.sh` | color PNG | V4L2 raw + software debayer. `DEV=` selects the node, `GRAY=1` for grayscale. |
| `capture_argus_image.sh` | color JPEG | Argus pipeline still. `SENSOR_ID=` selects the camera. |
| `preview_argus.sh` | screen | Argus live preview. Needs `DISPLAY=:0`. `SENSOR_ID=`, `WB=`. |
| `capture_argus_mono_image.sh` | grayscale JPEG/PNG | GRAY8 still for a mono IMX462 / IMX290 module. |
| `preview_argus_mono.sh` | screen | GRAY8 live preview for a mono module. |
| `imx462_raw16_to_pnm.py` | — | RAW16 → PPM/PGM converter used by `capture_v4l2_image.sh`. |

## Examples

```bash
# V4L2 raw (works without Argus), CAM0 then CAM1:
./capture_v4l2_image.sh /tmp/cam0.png
DEV=/dev/video1 ./capture_v4l2_image.sh /tmp/cam1.png

# Argus color still / preview:
./capture_argus_image.sh /tmp/cam0.jpg
SENSOR_ID=1 ./capture_argus_image.sh /tmp/cam1.jpg
DISPLAY=:0 ./preview_argus.sh

# Mono module (grayscale):
./capture_argus_mono_image.sh /tmp/mono.jpg
DISPLAY=:0 ./preview_argus_mono.sh
```

A 1920×1080 RG10 frame is 1920×1080×2 = 4,147,200 bytes.

> Overlay activation is not a script — pick one overlay with jetson-io and reboot:
> `sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -l`, then
> `… -n '2=<overlay-name>'`. Do not hand-edit `/boot/extlinux/extlinux.conf`.

See `../USER_MANUAL.md` for crystal switching, HCG/LCG switching, and
troubleshooting.
