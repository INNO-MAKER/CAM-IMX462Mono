#!/bin/bash
# Live color preview via Argus ISP (requires an active IMX462 dtbo + reboot,
# nvargus-daemon running, and a display: DISPLAY=:0 ./preview_argus.sh).
# Usage: DISPLAY=:0 [SENSOR_ID=0|1] [WB=1] ./preview_argus.sh [duration_seconds]
#   SENSOR_ID=1 -> CAM1 (default 0 = CAM0)
#   WB= Argus white-balance preset (default 1=auto):
#       0=off 1=auto 2=incandescent 5=daylight 6=cloudy 7=twilight 8=shade
set -e
SENSOR_ID="${SENSOR_ID:-0}"
W="${W:-1920}"
H="${H:-1080}"
FRAMERATE="${FRAMERATE:-30/1}"
WB="${WB:-1}"
DURATION="${1:-0}"
PREVIEW_SINK="${PREVIEW_SINK:-}"

if [ -z "$PREVIEW_SINK" ]; then
  if gst-inspect-1.0 nv3dsink >/dev/null 2>&1; then PREVIEW_SINK="nv3dsink"
  elif gst-inspect-1.0 nveglglessink >/dev/null 2>&1; then PREVIEW_SINK="nveglglessink"
  else PREVIEW_SINK="autovideosink"; fi
fi

NUM_BUFFERS_ARG=()
if [ "$DURATION" -gt 0 ] 2>/dev/null; then
  NUM_BUFFERS=$(( DURATION * 30 ))
  NUM_BUFFERS_ARG=(num-buffers="$NUM_BUFFERS")
fi

echo "preview ${W}x${H} sensor-id=${SENSOR_ID} wb=${WB} sink=${PREVIEW_SINK}"
gst-launch-1.0 -e \
  nvarguscamerasrc sensor-id="$SENSOR_ID" sensor-mode=0 wbmode="$WB" "${NUM_BUFFERS_ARG[@]}" \
  ! "video/x-raw(memory:NVMM),width=${W},height=${H},format=NV12,framerate=${FRAMERATE}" \
  ! nvvidconv \
  ! "video/x-raw,format=I420" \
  ! videoconvert \
  ! fpsdisplaysink video-sink="$PREVIEW_SINK" text-overlay=false sync=false
