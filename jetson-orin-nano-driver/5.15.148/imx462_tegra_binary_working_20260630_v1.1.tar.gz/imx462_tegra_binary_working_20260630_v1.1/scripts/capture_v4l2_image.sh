#!/bin/bash
# Capture one IMX462 RAW10 frame via V4L2 and convert to a PNG.
# Usage: ./capture_v4l2_image.sh [output.png]
#   GRAY=1 ./capture_v4l2_image.sh out.png   -> grayscale (bayer2x2 luma) instead of color
# IMX462 (Starvis-1, IMX290/327 family) outputs 1920x1080 RG10 (10-bit packed
# in a 16-bit container); BLKLEVEL default 0x3C (60). No optical-black padding
# in the V4L2 output (X_OUT_SIZE = active width).
set -e
OUT="${1:-/tmp/imx462_capture.png}"
DEV="${DEV:-/dev/video0}"
GRAY="${GRAY:-0}"
# Gray-world white-balance gains (G=1.0). Override via WB_R/WB_B for your scene.
WB_R="${WB_R:-1.99}"
WB_B="${WB_B:-1.31}"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
RAW=$(mktemp /tmp/imx462_raw.XXXXXX)
PNM="${RAW}.pnm"
trap 'rm -f "$RAW" "$PNM"' EXIT

v4l2-ctl -d "$DEV" \
  --set-fmt-video=width=1920,height=1080,pixelformat=RG10 \
  --stream-mmap --stream-skip=4 --stream-count=1 --stream-to="$RAW"

if [ "$GRAY" = "1" ]; then
  python3 "$SCRIPT_DIR/imx462_raw16_to_pnm.py" \
    --input "$RAW" --output "$PNM" \
    --width 1920 --height 1080 --crop-width 1920 --crop-height 1080 \
    --left 0 --top 0 \
    --format pgm --mono-method bayer2x2 --auto-levels \
    --raw-bits 10 --white 1023 --black 60
else
  python3 "$SCRIPT_DIR/imx462_raw16_to_pnm.py" \
    --input "$RAW" --output "$PNM" \
    --width 1920 --height 1080 --crop-width 1920 --crop-height 1080 \
    --left 0 --top 0 \
    --format ppm --auto-levels \
    --raw-bits 10 --white 1023 --black 60 \
    --wb-r "$WB_R" --wb-b "$WB_B"
fi

gst-launch-1.0 -q filesrc location="$PNM" ! pnmdec ! videoconvert ! pngenc ! filesink location="$OUT"
echo "saved: $OUT"
