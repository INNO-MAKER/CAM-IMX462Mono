#!/usr/bin/env bash
# Install the PRECOMPILED IMX462 driver on a Jetson Orin Nano (no build step).
#   - installs the prebuilt, stripped binary/imx462.ko
#   - copies both crystal variants of the cam0 / cam1 / dual overlays to /boot
#   - installs the tuned ISP override (backs up any existing one first)
#   - stamps THIS machine's CSI header name into each /boot dtbo (BSP-proof)
#   - configures module autoload
#
# The single imx462.ko auto-detects the board crystal from the activated DT's
# mode0 "mclk_khz" (74250 -> 1080p60 / 891 Mbit/s; 37125 -> 1080p30 / 445.5
# Mbit/s). No module param is needed -- just activate the overlay for your board.
#
# Overlay activation is done with jetson-io ONLY (see end of this script). This
# installer NEVER reads or writes /boot/extlinux/extlinux.conf, and does NOT
# reboot. Run with sudo:  sudo bash scripts/install_binary.sh
set -euo pipefail

PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
KO_SRC="${PKG_DIR}/binary/imx462.ko"
OVERLAY_DIR="${PKG_DIR}/overlays"
MODULE_DIR="/lib/modules/$(uname -r)/kernel/drivers/media/i2c"
ISP_NAME="camera_overrides.imx462_tuned.isp"
ISP_SRC="${PKG_DIR}/isp/${ISP_NAME}"
ISP_SETTINGS_DIR="/var/nvidia/nvcam/settings"
ISP_DST="${ISP_SETTINGS_DIR}/camera_overrides.isp"
ISP_BACKUP_DIR="${ISP_SETTINGS_DIR}/backup_imx462_isp"
OVERLAYS=(
	tegra234-imx462-cam0 tegra234-imx462-cam1 tegra234-imx462-dual
	tegra234-imx462-cam0-37m tegra234-imx462-cam1-37m tegra234-imx462-dual-37m
)

[ -f "${KO_SRC}" ] || { echo "ERROR: missing ${KO_SRC}" >&2; exit 1; }

# The prebuilt .ko is tied to the kernel it was built against. Warn (don't fail)
# if the running kernel differs -- the customer may have to use the source package.
KO_VERMAGIC="$(modinfo -F vermagic "${KO_SRC}" 2>/dev/null | awk '{print $1}')"
if [ -n "${KO_VERMAGIC}" ] && [ "${KO_VERMAGIC}" != "$(uname -r)" ]; then
	echo "WARNING: imx462.ko was built for kernel ${KO_VERMAGIC}, but you are"
	echo "         running $(uname -r). If 'modprobe imx462' fails with"
	echo "         'invalid module format', use the SOURCE package instead."
fi

echo "=== Installing prebuilt module ==="
install -D -m 0644 "${KO_SRC}" "${MODULE_DIR}/imx462.ko"
depmod -a

echo "=== Copying overlays to /boot ==="
for n in "${OVERLAYS[@]}"; do
	[ -f "${OVERLAY_DIR}/${n}.dtbo" ] || { echo "ERROR: missing ${OVERLAY_DIR}/${n}.dtbo" >&2; exit 1; }
	install -D -m 0644 "${OVERLAY_DIR}/${n}.dtbo" "/boot/${n}.dtbo"
done

# Stamp THIS machine's actual CSI header name into each installed dtbo. jetson-io
# only lists an overlay whose jetson-header-name string-equals the live header
# name, which is BSP-specific (e.g. "Jetson 24pin CSI Connector" vs 22pin).
HDR="$(python3 /opt/nvidia/jetson-io/config-by-hardware.py -l 2>/dev/null \
       | grep -oE 'Jetson [0-9]+pin CSI Connector' | head -1 || true)"
if [ -n "${HDR}" ] && command -v fdtput >/dev/null 2>&1; then
	echo "=== Stamping jetson-header-name = '${HDR}' into installed overlays ==="
	for n in "${OVERLAYS[@]}"; do
		fdtput -t s "/boot/${n}.dtbo" / jetson-header-name "${HDR}" || true
	done
else
	echo "  NOTE: could not auto-detect the CSI header name; if jetson-io does"
	echo "        not list the IMX462 overlays, install device-tree-compiler"
	echo "        (provides fdtput) and re-run."
fi

if [ -f "${ISP_SRC}" ]; then
	echo "=== Installing tuned ISP override ==="
	mkdir -p "${ISP_SETTINGS_DIR}" "${ISP_BACKUP_DIR}"
	if [ -f "${ISP_DST}" ] && ! cmp -s "${ISP_SRC}" "${ISP_DST}"; then
		stamp="$(date +%Y%m%d_%H%M%S)"
		cp "${ISP_DST}" "${ISP_BACKUP_DIR}/camera_overrides.isp.${stamp}.bak"
		echo "  backed up existing ISP to ${ISP_BACKUP_DIR}/camera_overrides.isp.${stamp}.bak"
	fi
	install -m 0644 "${ISP_SRC}" "${ISP_DST}"
	install -m 0644 "${ISP_SRC}" "${ISP_SETTINGS_DIR}/${ISP_NAME}"
fi

echo "=== Configuring module autoload ==="
mkdir -p /etc/modules-load.d
echo imx462 > /etc/modules-load.d/imx462.conf

cat <<'EOF'

Installed (prebuilt):
  imx462.ko -> /lib/modules/$(uname -r)/kernel/drivers/media/i2c/
  74.25 MHz crystal -> 1080p60 (891 Mbit/s/lane):
    /boot/tegra234-imx462-{cam0,cam1,dual}.dtbo
  37.125 MHz crystal -> 1080p30 (445.5 Mbit/s/lane):
    /boot/tegra234-imx462-{cam0,cam1,dual}-37m.dtbo

The single imx462.ko auto-matches whichever overlay you activate. No param needed.

This installer did NOT reboot and did NOT touch extlinux.conf.

NEXT (you do this): activate ONE overlay matching YOUR crystal, then reboot.

1) List the CSI header number + exact overlay menu names:
     sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -l

2) Enable the IMX462 Dual overlay for your crystal (CSI = header 2 on Orin Nano):
     # 74.25 MHz board (1080p60):
     sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -n '2=Camera IMX462 Dual (CAM0+CAM1)'
     # 37.125 MHz board (1080p30):
     sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -n '2=Camera IMX462 Dual 30fps (37.125MHz)'

   (For a single sensor, use the matching 'Camera IMX462 CAM0[ 30fps (37.125MHz)]'.)

3) Reboot to bring the camera up:
     sudo reboot
EOF
